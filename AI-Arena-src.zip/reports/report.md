# AI 角斗场 · 评测速览

- **heuristic-conservative**：对局 155 场，胜 93 场，胜率 60%，平均猜想命中率 26%
- **heuristic-aggressive**：对局 93 场，胜 49 场，胜率 53%，平均猜想命中率 18%
- **heuristic:aggressive**：对局 24 场，胜 10 场，胜率 42%，平均猜想命中率 25%
- **heuristic:creative**：对局 22 场，胜 9 场，胜率 41%，平均猜想命中率 25%
- **heuristic-balanced**：对局 17 场，胜 6 场，胜率 35%，平均猜想命中率 37%
- **heuristic**：对局 5 场，胜 5 场，胜率 100%，平均猜想命中率 50%
- **heuristic:balanced**：对局 22 场，胜 5 场，胜率 23%，平均猜想命中率 21%
- **heuristic-creative**：对局 12 场，胜 1 场，胜率 8%，平均猜想命中率 28%
- **heuristic:conservative**：对局 24 场，胜 1 场，胜率 4%，平均猜想命中率 17%

🏆 当前领跑：**heuristic-conservative**（胜率 60%）

## 推理能力画像（四维）

| 玩家 | 推理准确 | 信息效率 | 命中广度 | 收网果断 |
|---|---|---|---|---|
| heuristic | 50% | 0.25 | 50% | 35% |
| heuristic-aggressive | 18% | 0.42 | 43% | 57% |
| heuristic-balanced | 37% | 0.17 | 39% | 37% |
| heuristic-conservative | 26% | 0.40 | 89% | 21% |
| heuristic-creative | 28% | 0.13 | 29% | 38% |
| heuristic:aggressive | 25% | 0.26 | 30% | 0% |
| heuristic:balanced | 21% | 0.24 | 36% | 0% |
| heuristic:conservative | 17% | 0.26 | 38% | 0% |
| heuristic:creative | 25% | 0.18 | 28% | 0% |

> 说明：项目目标是推理/欺骗/伪装/辩论四维能力，但后三者需对抗模式才能观测，
> 当前雷达图只反映**推理侧的四种风格**，不是完整的四维能力评分。