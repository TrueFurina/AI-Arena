# AI 角斗场 · 评测速览

- **heuristic-conservative**：对局 12 场，胜 5 场，胜率 42%，平均猜想命中率 21%
- **heuristic-aggressive**：对局 12 场，胜 4 场，胜率 33%，平均猜想命中率 18%
- **heuristic-creative**：对局 12 场，胜 1 场，胜率 8%，平均猜想命中率 28%
- **heuristic-balanced**：对局 12 场，胜 1 场，胜率 8%，平均猜想命中率 25%

🏆 当前领跑：**heuristic-conservative**（胜率 42%）

## 推理能力画像（四维）

| 玩家 | 推理准确 | 信息效率 | 命中广度 | 收网果断 |
|---|---|---|---|---|
| heuristic-aggressive | 18% | 0.22 | 29% | 62% |
| heuristic-balanced | 25% | 0.15 | 35% | 37% |
| heuristic-conservative | 21% | 0.15 | 36% | 28% |
| heuristic-creative | 28% | 0.13 | 29% | 38% |

> 说明：项目目标是推理/欺骗/伪装/辩论四维能力，但后三者需对抗模式才能观测，
> 当前雷达图只反映**推理侧的四种风格**，不是完整的四维能力评分。